jQuery(document).ready(function($) {
    // For debug: show modal after 1 second regardless of cookies
    setTimeout(function() {
        $('#glc-modal-overlay').show();
        $('#cookieModal').addClass('active');
        console.log('Modal shown (debug mode)');
    }, 1000);

    // Simple event handlers (for testing)
    $('#continueButton').on('click', function() {
        var prefs = 'necessary';
        if ($('#analyticsCookies').is(':checked')) prefs += ',analytics';
        if ($('#marketingCookies').is(':checked')) prefs += ',marketing';
        $.post(glc_ajax.ajax_url, {
            action: 'glc_save_consent',
            nonce: glc_ajax.nonce,
            preferences: prefs
        });
        $('#glc-modal-overlay').hide();
        $('#cookieModal').removeClass('active');
    });
    $('#rejectAllBtn').on('click', function() {
        $.post(glc_ajax.ajax_url, {
            action: 'glc_save_consent',
            nonce: glc_ajax.nonce,
            preferences: 'necessary'
        });
        $('#glc-modal-overlay').hide();
        $('#cookieModal').removeClass('active');
    });
    // Toggle progress
    $('.optional-cookie').on('change', function() {
        var count = ($('#analyticsCookies').is(':checked') ? 1 : 0) + ($('#marketingCookies').is(':checked') ? 1 : 0);
        $('#acceptedCount').text(count);
        $('#progressFill').css('width', (count/2*100)+'%');
        $('#continueButton').prop('disabled', false);
    });
});
