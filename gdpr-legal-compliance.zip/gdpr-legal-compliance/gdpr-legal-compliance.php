<?php
/**
 * Plugin Name: GDPR Legal Compliance
 * Description: Cookie consent modal with GTM and third-party script blocking.
 * Version: 1.0
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'GLC_PATH', plugin_dir_path( __FILE__ ) );
define( 'GLC_URL', plugin_dir_url( __FILE__ ) );
define( 'GLC_VERSION', '1.0' );

// Include required files
require_once GLC_PATH . 'includes/class-db.php';
require_once GLC_PATH . 'includes/class-consent-log.php';
require_once GLC_PATH . 'includes/class-settings.php';
require_once GLC_PATH . 'includes/class-banner.php';

// Activation
register_activation_hook( __FILE__, array( 'GLC_DB', 'create_tables' ) );

// Init
function glc_init() {
    GLC_Settings::init();
    GLC_Banner::init();
    GLC_Consent_Log::init();
}
add_action( 'plugins_loaded', 'glc_init' );
