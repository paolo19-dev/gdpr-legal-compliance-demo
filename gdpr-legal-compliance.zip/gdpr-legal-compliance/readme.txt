=== GDPR Legal Compliance ===
Contributors: yourusername
Tags: gdpr, cookie consent, cookie banner, compliance, privacy, gtm, google tag manager, script blocking, consent log
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

GDPR Legal Compliance provides a modern cookie consent modal with granular controls and automatic blocking of third‑party scripts until explicit user consent.

== Description ==

This plugin helps you comply with GDPR and ePrivacy regulations by:

* Displaying a beautiful, responsive cookie consent modal with three categories: Essential (required), Analytics, and Marketing.
* Allowing users to enable/disable optional cookies via toggle switches.
* Blocking Google Tag Manager and other third‑party scripts until the user gives consent for Analytics or Marketing categories.
* Logging all consent choices (with hashed IP and user agent) for audit purposes.
* Providing a "Revoke Consent" shortcode so users can change their preferences anytime.

No configuration is required to get started – just activate and the banner will appear. If you use GTM, enter your container ID in Settings → GDPR.

== Installation ==

1. Upload the entire `gdpr-legal-compliance` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Optionally, go to **Settings → GDPR** and enter your Google Tag Manager ID.
4. The cookie banner will automatically appear for new visitors.

== Frequently Asked Questions ==

= How do I customize the banner style? =

All CSS is in `/assets/css/cookie-banner.css`. You can override it in your theme's stylesheet or via Customizer.

= Does the plugin work with caching plugins? =

Yes, but make sure to exclude the cookie `glc_consent` from caching (most caching plugins allow this) so that the banner visibility is correctly handled.

= Can I add more cookie categories? =

Yes, you can extend the banner HTML and JavaScript, and also add your own consent categories. The plugin is developer‑friendly and includes filters for script blocking.

= How is the IP address stored? =

The IP is hashed using `wp_hash()` with WordPress secret salt, making it irreversible and GDPR‑compliant (pseudonymous data).

= Is the plugin translation ready? =

Yes, it includes a `.pot` file in the `/languages/` folder and uses the text domain `glc`. Use Loco Translate or Poedit to create your own translation.

== Screenshots ==

1. The cookie consent modal (front‑end).
2. Settings page (admin).
3. Consent log viewer (admin).

== Changelog ==

= 1.0.0 =
* Initial release.
* Cookie consent modal with toggles.
* GTM blocking and script management.
* Consent logging and revoke shortcode.
* Fully translatable.

== Upgrade Notice ==

= 1.0.0 =
First stable version – ready for production.
