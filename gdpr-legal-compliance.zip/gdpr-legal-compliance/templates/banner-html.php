<!-- DEBUG: banner-html included -->
<div id="glc-modal-overlay" class="glc-modal-overlay" style="display:none;"></div>
<div class="cookie-modal" id="cookieModal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Cookie Preferences Required</h2>
            <p>To access our website, configure your cookie preferences using the toggles below.</p>
            <div class="progress-indicator">
                <div class="progress-text"><span id="acceptedCount">0</span> out of <span id="totalCount">2</span> optional categories accepted</div>
                <div class="progress-bar"><div class="progress-fill" id="progressFill"></div></div>
            </div>
        </div>
        <div class="cookie-cards">
            <!-- Essential -->
            <div class="cookie-card required">
                <div class="card-header"><div class="card-title">Essential Cookies</div><div class="card-badge">Required</div></div>
                <p class="card-description">These cookies are necessary for the website to function...</p>
                <a href="/cookies/essential" class="card-link">Learn more →</a>
                <div class="toggle-container"><span class="toggle-label">Always Active</span><label class="toggle-switch"><input type="checkbox" checked disabled><span class="slider"></span></label></div>
            </div>
            <!-- Analytics -->
            <div class="cookie-card">
                <div class="card-header"><div class="card-title">Analytics Cookies</div><div class="card-badge">Optional</div></div>
                <p class="card-description">These cookies allow us to count visits...</p>
                <a href="/cookies/analytics" class="card-link">Learn more →</a>
                <div class="toggle-container"><span class="toggle-label">Analytics</span><label class="toggle-switch"><input type="checkbox" id="analyticsCookies" class="optional-cookie"><span class="slider"></span></label></div>
            </div>
            <!-- Marketing -->
            <div class="cookie-card">
                <div class="card-header"><div class="card-title">Marketing Cookies</div><div class="card-badge">Optional</div></div>
                <p class="card-description">These cookies are set by our advertising partners...</p>
                <a href="/cookies/marketing" class="card-link">Learn more →</a>
                <div class="toggle-container"><span class="toggle-label">Marketing</span><label class="toggle-switch"><input type="checkbox" id="marketingCookies" class="optional-cookie"><span class="slider"></span></label></div>
            </div>
        </div>
        <div class="modal-footer">
            <button class="cookie-btn btn-reject" id="rejectAllBtn">Reject All Optional Cookies</button>
            <button class="cookie-btn btn-accept" id="continueButton" disabled>Continue to Website</button>
        </div>
    </div>
</div>
