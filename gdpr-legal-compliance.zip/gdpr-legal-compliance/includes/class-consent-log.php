<?php
class GLC_Consent_Log {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_log_page' ) );
    }
    public static function save( $preferences ) {
        global $wpdb;
        $table = $wpdb->prefix . 'glc_consents';
        $wpdb->insert( $table, array(
            'consent_date'        => current_time( 'mysql' ),
            'ip_address'          => hash( 'sha256', $_SERVER['REMOTE_ADDR'] ),
            'consent_preferences' => sanitize_text_field( $preferences ),
            'user_agent'          => sanitize_text_field( $_SERVER['HTTP_USER_AGENT'] ),
        ) );
    }
    public static function add_log_page() {
        add_submenu_page( 'options-general.php', 'Consent Log', 'Consent Log', 'manage_options', 'glc-consent-log', array( __CLASS__, 'render' ) );
    }
    public static function render() {
        global $wpdb;
        $table = $wpdb->prefix . 'glc_consents';
        $results = $wpdb->get_results( "SELECT * FROM $table ORDER BY consent_date DESC LIMIT 50" );
        echo '<div class="wrap"><h1>Consent Log</h1><table class="widefat"><thead><tr><th>ID</th><th>Date</th><th>IP (hash)</th><th>Preferences</th></tr></thead><tbody>';
        foreach ( $results as $r ) {
            echo '<tr><td>'.$r->id.'</td><td>'.$r->consent_date.'</td><td>'.substr($r->ip_address,0,16).'...</td><td>'.$r->consent_preferences.'</td></tr>';
        }
        echo '</tbody></table></div>';
    }
}
