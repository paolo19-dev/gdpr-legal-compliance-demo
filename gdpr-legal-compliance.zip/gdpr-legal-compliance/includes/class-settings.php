<?php
class GLC_Settings {
    public static function init() {
        add_action( 'admin_menu', array( __CLASS__, 'add_page' ) );
        add_action( 'admin_init', array( __CLASS__, 'register' ) );
    }
    public static function add_page() {
        add_options_page( 'GDPR Settings', 'GDPR', 'manage_options', 'glc-settings', array( __CLASS__, 'render' ) );
    }
    public static function register() {
        register_setting( 'glc_group', 'glc_gtm_id' );
    }
    public static function render() {
        ?>
        <div class="wrap">
            <h1>GDPR Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields( 'glc_group' ); ?>
                <table class="form-table">
                    <tr>
                        <th>Google Tag Manager ID</th>
                        <td><input type="text" name="glc_gtm_id" value="<?php echo esc_attr( get_option( 'glc_gtm_id' ) ); ?>" placeholder="GTM-XXXXXX"></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }
}
