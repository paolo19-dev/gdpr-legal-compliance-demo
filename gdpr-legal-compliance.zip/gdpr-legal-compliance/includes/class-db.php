<?php
class GLC_DB {
    public static function create_tables() {
        global $wpdb;
        $table = $wpdb->prefix . 'glc_consents';
        $sql = "CREATE TABLE IF NOT EXISTS $table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            consent_date datetime NOT NULL,
            ip_address varchar(64) NOT NULL,
            consent_preferences text NOT NULL,
            user_agent text,
            revoked tinyint(1) DEFAULT 0,
            PRIMARY KEY (id)
        ) {$wpdb->get_charset_collate()};";
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta($sql);
        add_option( 'glc_gtm_id', '' );
    }
}