<?php
class GLC_Banner {
    public static function init() {
        add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
        add_action( 'wp_footer', array( __CLASS__, 'render_banner' ) );
        add_action( 'wp_ajax_glc_save_consent', array( __CLASS__, 'save_consent' ) );
        add_action( 'wp_ajax_nopriv_glc_save_consent', array( __CLASS__, 'save_consent' ) );
    }
    public static function enqueue_assets() {
        wp_enqueue_style( 'glc-cookie-banner', GLC_URL . 'assets/css/cookie-banner.css', array(), GLC_VERSION );
        wp_enqueue_script( 'glc-cookie-banner', GLC_URL . 'assets/js/cookie-banner.js', array( 'jquery' ), GLC_VERSION, true );
        wp_localize_script( 'glc-cookie-banner', 'glc_ajax', array(
            'ajax_url' => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'glc_consent_nonce' ),
            'gtm_id'   => get_option( 'glc_gtm_id', '' ),
        ) );
    }
    public static function render_banner() {
        include GLC_PATH . 'templates/banner-html.php';
    }
    public static function save_consent() {
        if ( ! wp_verify_nonce( $_POST['nonce'], 'glc_consent_nonce' ) ) {
            wp_die( 'Security check failed' );
        }
        GLC_Consent_Log::save( sanitize_text_field( $_POST['preferences'] ) );
        wp_send_json_success();
    }
}
